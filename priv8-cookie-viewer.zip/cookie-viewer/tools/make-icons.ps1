# Generates placeholder icons (16, 48, 128) using PowerShell
param(
  [string]$OutDir = (Split-Path -Parent $MyInvocation.MyCommand.Path)
)

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = Split-Path -Parent $here
Set-Location $root

# Create a simple bitmap with background and text using Windows Forms
Add-Type -AssemblyName System.Drawing

function New-Icon {
  param(
    [int]$Size,
    [string]$Path
  )
  $bmp = New-Object System.Drawing.Bitmap($Size, $Size)
  $g = [System.Drawing.Graphics]::FromImage($bmp)
  $bg = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(255, 30, 136, 229))
  $g.FillRectangle($bg, 0,0,$Size,$Size)
  $sf = New-Object System.Drawing.StringFormat
  $sf.Alignment = 'Center'
  $sf.LineAlignment = 'Center'
  $fontSize = [Math]::Max([int]($Size*0.45), 8)
  $font = New-Object System.Drawing.Font('Segoe UI', $fontSize, [System.Drawing.FontStyle]::Bold)
  $g.SmoothingMode = 'AntiAlias'
  $g.DrawString('CK', $font, [System.Drawing.Brushes]::White, [System.Drawing.RectangleF]::new(0,0,$Size,$Size), $sf)
  $bmp.Save($Path, [System.Drawing.Imaging.ImageFormat]::Png)
  $g.Dispose(); $bmp.Dispose()
}

New-Icon -Size 16 -Path (Join-Path $root 'icon16.png')
New-Icon -Size 48 -Path (Join-Path $root 'icon48.png')
New-Icon -Size 128 -Path (Join-Path $root 'icon128.png')

Write-Host "Icons generated at:" (Join-Path $root 'icon16.png'), (Join-Path $root 'icon48.png'), (Join-Path $root 'icon128.png')
